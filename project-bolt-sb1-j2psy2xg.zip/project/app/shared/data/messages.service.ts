import { Observable } from '@nativescript/core';
import { Message } from '../models/message.model';

export class MessagesService extends Observable {
  private messages: Message[] = [
    {
      id: '1',
      text: '¡Hola! ¿Cómo estás?',
      sender: 'Juan',
      timestamp: new Date(),
      isMine: false
    },
    {
      id: '2',
      text: '¡Muy bien! ¿Y tú?',
      sender: 'Me',
      timestamp: new Date(),
      isMine: true
    }
  ];

  getMessages(): Message[] {
    return this.messages;
  }

  sendMessage(text: string): void {
    const newMessage: Message = {
      id: Date.now().toString(),
      text,
      sender: 'Me',
      timestamp: new Date(),
      isMine: true
    };
    this.messages.push(newMessage);
    this.notifyPropertyChange('messages', this.messages);
  }
}