export interface Message {
  id: string;
  text: string;
  sender: string;
  timestamp: Date;
  isMine: boolean;
}