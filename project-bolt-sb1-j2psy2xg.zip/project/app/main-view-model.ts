import { Observable } from '@nativescript/core';
import { MessagesService } from './shared/data/messages.service';
import { Message } from './shared/models/message.model';

export class ChatViewModel extends Observable {
  private messagesService: MessagesService;
  private _messageText: string = '';
  private _messages: Message[] = [];

  constructor() {
    super();
    this.messagesService = new MessagesService();
    this._messages = this.messagesService.getMessages();
  }

  get messages(): Message[] {
    return this._messages;
  }

  get messageText(): string {
    return this._messageText;
  }

  set messageText(value: string) {
    if (this._messageText !== value) {
      this._messageText = value;
      this.notifyPropertyChange('messageText', value);
    }
  }

  onSendMessage() {
    if (this._messageText.trim()) {
      this.messagesService.sendMessage(this._messageText.trim());
      this._messages = this.messagesService.getMessages();
      this.notifyPropertyChange('messages', this._messages);
      this.messageText = '';
    }
  }
}